import java.util.Stack;
//              "USAGE: java Operations (base 10) 0b(binary) 0x(HEX)"

public class Operations {

    // reads input and returns radix solely based off prefix or lack thereof.
    public static String getBase(String input) {
        if (input.charAt(0) != '0' || input.length() < 2) {
            return "Decimal";
        }
        // has prefix 0b
        if (input.substring(0, 2).equals("0b")) {
            return "Binary";
        }
        // has prefix 0x
        if (input.substring(0, 2).equals("0x")) {
            return "Hexadecimal";
        }// is decimal
        else {
            return "I dunno";
        }
    }

    // reads input and returns if valid || invalid.
    public static String isValid(String input) {
        // if is binary then see if it only contains 0-1 ret true if.
        if (getBase(input).equals("Binary")) {
            if (input.substring(2).matches("[0-1]+") || input.substring(2).length() == 0) {
                return "true";
            }
        }
        // if is decimal then see if it only contains 0-9 ret true if.
        if (getBase(input).equals("Decimal")) {
            if (input.matches("[0-9]+")) {
                return "true";
            }
        }
        // if is hexadecimal then see if contains 0-9a-fA-F ret true if.
        if (getBase(input).equals("Hexadecimal")) {
            if (input.substring(2).matches("[a-fA-F0-9]+") || input.substring(2).length() == 0) {
                return "true";
            }
        }
        // or return false
        return "false";
    }

    // helper method for Task 4
    public static void theWorks(String input) {
        // Start number
        System.out.print("Start=" + input);

        // To binary
        String binary = "0b";
        // if is already respective number, print.
        if (getBase(input).equals("Binary")) {
            binary = input;
        } else if (getBase(input).equals("Decimal")) {

            Stack<Integer> s = new Stack<Integer>();
            int placeval;
            int sum = 0;

            for (int i = 0; i < input.length(); i++) {
                placeval = input.charAt(i) - 48;
                sum += placeval * Math.pow(10, input.length() - 1 - i);
            }
            if (sum == 0 && input.length() == 1) {
                binary += 0;
            }

            while (sum != 0) {
                s.push(sum % 2);
                sum /= 2;
            }
            while (!s.isEmpty()) {
                int popval = s.pop();
                popval += 48;
                binary += (char) popval;
            }

        } else if (getBase(input).equals("Hexadecimal")) {

            // hex to binary .... get decimal value for a letter covert single letter to its
            // respective binary number (0-15) and concatenate to binary
            Stack<Integer> s = new Stack<Integer>();

            for (int i = 0; i < input.length() - 2; i++) {

                int trueval;

                if (!Character.isDigit(input.charAt(i + 2))) {
                    trueval = Character.toUpperCase(input.charAt(i + 2)) - 55; // if value is a letter convert to
                }// uppercase and subtract 55 to get its
                // raw decimal value.
                else {
                    trueval = input.charAt(i + 2) - 48;
                }
                while (trueval != 0) {
                    s.push(trueval % 2);
                    trueval /= 2;
                }
                int size = s.size();
                while (size < 4) {
                    binary += "0";
                    size++;
                }
                while (!s.isEmpty()) {
                    binary += "" + s.pop();
                }
            }

        }

        System.out.print(",Binary=" + binary);

        // To decimal
        String decimal = "";
        // if is already respective number, print.
        if (getBase(input).equals("Decimal")) {
            decimal = input;
        } else if (getBase(input).equals("Binary")) {
            // first parse all values of the binary and add Math.pow(2,n) to raw value.
            int raw = 0;
            for (int i = 2; i < input.length(); i++) {
                if (input.charAt(i) - '0' == 1) {
                    raw += Math.pow(2, input.length() - i - 1);
                }
            }
            decimal += "" + raw;
        } else if (getBase(input).equals("Hexadecimal")) {

            // first get each individual hex value and multiply by its place value and add
            // to a sum
            int sum = 0;
            int trueval;
            for (int i = 0; i < input.length() - 2; i++) {
                if (!Character.isDigit(input.charAt(i + 2))) {
                    trueval = (Character.toUpperCase(input.charAt(i + 2)) - 55);
                } else {
                    trueval = input.charAt(i + 2) - 48;
                }
                // System.out.println("\n"+trueval+"\n");

                sum += trueval * (Math.pow(16, input.length() - 3 - i));
                trueval = 0;
            }
            decimal = "" + sum;

        }

        System.out.print(",Decimal=" + decimal);

        //                                                                           To hex
        String hex = "0x";
        // if is already respective number, print.
        if (getBase(input).equals("Hexadecimal")) {
            hex = input;
        }// parse input into decimal sum and divide by 16, note remainder if remainder >
        // 9 change to char value [a-f].
        else if (getBase(input).equals("Decimal")) {

            Stack<Integer> s = new Stack<Integer>();
            int placeval;
            int sum = 0;

            for (int i = 0; i < input.length(); i++) {
                placeval = input.charAt(i) - 48;
                sum += placeval * Math.pow(10, input.length() - 1 - i);
            }
            if (sum == 0 && input.length() < 2) {
                hex += 0;
            }
            while (sum != 0) {
                s.push(sum % 16);
                sum /= 16;
            }
            while (!s.isEmpty()) {
                int popval = s.pop();
                if (popval > 9) {
                    popval += 87;
                } else {
                    popval += 48;
                }
                hex += (char) popval;

            }

        } else if (getBase(input).equals("Binary")) {

            // first divide binary string into 4 bits and convert to a raw value push to a
            // stack
            int raw = 0;
            String temp = input.substring(2);
            Stack<Integer> s = new Stack();
            String fourbit;

            while (!(temp.length() - 4 < 0)) {
                fourbit = temp.substring(0, 4);
                for (int i = 0; i < fourbit.length(); i++) {
                    if (fourbit.charAt(i) == '1') {
                        raw += Math.pow(2, 3 - i);
                    }

                }

                if (raw > 9) {
                    hex += (char) (raw + 87);
                } else {
                    hex += (char) (raw + 48);
                }
                temp = temp.substring(4);
                raw = 0;
            }
            if (temp.length() > 0) {
                for (int i = 0; i < temp.length(); i++) {
                    if (temp.charAt(i) - '0' == 1) {
                        raw += Math.pow(2, temp.length() - 1 - i);
                    }
                }
                s.push(raw + 48);
            }

            // empty out stack from Integer to int to char in its respective ascii
            // designation
            while (!s.empty()) {
                hex += (char) (int) s.pop();
            }
        }

        System.out.print(",Hexadecimal=" + hex + "\n");

    }

    //                                                          END OF TASK 4
    //                                                      next tasks helper to binary converts anything to binary
    public static String toBinary(String input) {
        if (getBase(input).equals("Binary")) {
            return input;
        }

        String binary = "0b";

        if (getBase(input).equals("Decimal")) {
            Stack<Integer> s = new Stack<Integer>();
            int placeval;
            int sum = 0;

            for (int i = 0; i < input.length(); i++) {
                placeval = input.charAt(i) - 48;
                sum += placeval * Math.pow(10, input.length() - 1 - i);
            }
            if (sum == 0 && input.length() == 1) {
                binary += 0;
            }

            while (sum != 0) {
                s.push(sum % 2);
                sum /= 2;
            }
            while (!s.isEmpty()) {
                int popval = s.pop();
                popval += 48;
                binary += (char) popval;
            }
        }

        if (getBase(input).equals("Hexadecimal")) {
            Stack<Integer> s = new Stack<Integer>();

            for (int i = 0; i < input.length() - 2; i++) {

                int trueval;

                if (!Character.isDigit(input.charAt(i + 2))) {
                    trueval = Character.toUpperCase(input.charAt(i + 2)) - 55; // if value is a letter convert to
                }// uppercase and subtract 55 to get its
                // raw decimal value.
                else {
                    trueval = input.charAt(i + 2) - 48;
                }

                while (trueval != 0) {
                    s.push(trueval % 2);
                    trueval /= 2;
                }
                int size = s.size();
                while (size < 4) {
                    binary += "0";
                    size++;
                }
                while (!s.isEmpty()) {
                    binary += "" + s.pop();
                }
            }

        }
        return binary;
    }

    //                                                  !!!TASK 5!!!
    public static void onesComplement(String input) {
        String binarified = toBinary(input);
        String oneified = "";
        for (int i = 2; i < binarified.length(); i++) {
            if (binarified.charAt(i) == '1') {
                oneified += "0";
            } else {
                oneified += "1";
            }
        }
        System.out.println(input + "=" + binarified.substring(2) + "=" + oneified);
    }

    public static void twosComplement(String input) {
        String binarified = toBinary(input);
        String oneified = "";
        String twoified = "";
        for (int i = 2; i < binarified.length(); i++) {
            if (binarified.charAt(i) == '1') {
                oneified += "0";
            } else {
                oneified += "1";
            }
        }
        //try to add 1
        int carrycounter = 0;
        boolean overflow = false;
        //if the last value - already 1 isnt zero add to carry counter
        while (oneified.charAt(oneified.length() - 1 - carrycounter) != '0') {
            carrycounter += 1;
            if (carrycounter == oneified.length()) {
                overflow = true;
                break;
            }
        }
        if (!overflow) {
            twoified += oneified.substring(0, oneified.length() - 1 - carrycounter);
            twoified += "1";
        }
        while (carrycounter != 0) {
            twoified += "0";
            carrycounter--;
        }
        System.out.println(input + "=" + oneified + "=>" + twoified);
    }

    public static void logicOps(String var1, String var2, String var3) {
        //get binarificationism
        String bi1 = toBinary(var1).substring(2);
        String bi2 = toBinary(var2).substring(2);
        String bi3 = toBinary(var3).substring(2);

        // make all equal in length
        int big = Math.max(bi1.length(), Math.max(bi2.length(), bi3.length()));
        while (bi1.length() != big) {
            bi1 = "0" + bi1;
        }
        while (bi2.length() != big) {
            bi2 = "0" + bi2;
        }
        while (bi3.length() != big) {
            bi3 = "0" + bi3;
        }

        String or = "";
        //calc or
        for (int i = 0; i < big; i++) {
            if (bi1.charAt(i) == '1' || bi2.charAt(i) == '1' || bi3.charAt(i) == '1') {
                or += '1';
            } else {
                or += '0';
            }
        }
        System.out.println(toBinary(var1) + "|" + toBinary(var2) + "|" + toBinary(var3) + "=" + or);
        String and = "";
        //calc and
        for (int i = 0; i < big; i++) {
            if (bi1.charAt(i) == '1' && bi2.charAt(i) == '1' && bi3.charAt(i) == '1') {
                and += '1';
            } else {
                and += '0';
            }
        }
        System.out.println(toBinary(var1) + "&" + toBinary(var2) + "&" + toBinary(var3) + "=" + and);

        String xor = "";
        //calc xor
        for (int i = 0; i < big; i++) {
            if ((bi1.charAt(i) != bi2.charAt(i)) != getTF(bi3.charAt(i))) {
                xor += '1';
            } else {
                xor += '0';
            }
        }
        System.out.println(toBinary(var1) + "^" + toBinary(var2) + "^" + toBinary(var3) + "=" + xor);

    }

    public static boolean getTF(char in) {
        if (in == '1') {
            return true;
        } else {
            return false;
        }
    }

    //task 8
    public static void shift(String input) {
        String binarificationarianism = toBinary(input).substring(2);
        if (!(binarificationarianism.length() < 3)) {
            System.out.println(binarificationarianism + "<<2=" + binarificationarianism + "00," + binarificationarianism + ">>2=" + binarificationarianism.substring(0, binarificationarianism.length() - 2));
        } else {
            System.out.println(binarificationarianism + "<<2=" + binarificationarianism + "00," + binarificationarianism + ">>2=0");
        }

    }

    // start of main
    public static void main(String[] args) {
        // TASK 1
        System.out.println("Task 1");
        if (args.length != 3) {
            System.out.println("Incorrect number of arguments have been provided. Program Terminating!");
            System.exit(0);
        } else {
            System.out.println("Correct number of arguments given\n\nTask 2");
        }

        // TASK 2
        // loop removes redundancy
        for (int i = 0; i < 3; i++) {
            System.out.println(args[i] + "=" + getBase(args[i]));
        }

        System.out.println("\nTask 3");

        // TASK 3
        // likewise
        boolean isValid = true;
        for (int i = 0; i < 3; i++) {
            System.out.println(args[i] + "=" + isValid(args[i]));
            // if false ever prints trips this if statement and ends
            if (isValid(args[i]).equals("false")) {
                isValid = false;
            }
        }
        if (!isValid) {
            System.exit(0);
        }

        System.out.println("\nTask 4");

        // TASK 4
        // again
        for (int i = 0; i < 3; i++) {
            theWorks(args[i]);
        }

        System.out.println("\nTask 5");

        // TASK 5
        // for loooooop
        for (int i = 0; i < 3; i++) {
            onesComplement(args[i]);
        }

        System.out.println("\nTask 6");

        // TASK 6
        // another one
        for (int i = 0; i < 3; i++) {
            twosComplement(args[i]);
        }

        System.out.println("\nTask 7");

        // TASK 7
        logicOps(args[0], args[1], args[2]);

        System.out.println("\nTask 8");

        // Task 8
        //lor foop
        for (int i = 0; i < 3; i++) {
            shift(args[i]);
        }
    }
}