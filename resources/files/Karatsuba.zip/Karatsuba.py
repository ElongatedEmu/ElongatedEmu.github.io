
def karatsuba_mult(x, y):
    """
    Computes the product of integers x, y using Karatsuba's algorithm.
    
    Parameters:
        x: The first multiplicand.
        y: The second multiplicand.
        
    Returns:
        The product x * y.
    """
    if x<100 and y<100:
       # print(x,y)
        return x*y
    xn = max(len(str(x)),len(str(y)))
    yn = len(str(y))
    x1 = x//(10**(xn//2))
    x0 = x-(x1*10**(xn//2))
    y1 = y//(10**(xn//2))
    y0 = y-(y1*10**(xn//2))
   # print(x1,x0,y1,y0)
    #print("main")
    first_product = karatsuba_mult(x1,y1)
    #print("first")
    #print("second")
    last_product = karatsuba_mult(x0,y0)
    mid_product = karatsuba_mult(x1+x0,y1+y0) - first_product - last_product
    #Dprint("The: ", main_product,first_product,second_product)
    return first_product*(10**(xn//2*2)) + mid_product*(10**(xn//2)) + last_product

print(karatsuba_mult(1000,1000))