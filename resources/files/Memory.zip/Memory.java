import java.util.Random;
import java.util.TreeSet;
import java.util.ArrayList;

public class Memory {
    //USAGE java Memory <size> <experiments> <seed>
    public static volatile int i=0;

    public static long getAvg(long[] al) {
        long tot = 0;
        for (int p = 0; p<al.length;p++){
            tot+=al[p];
        }
        tot*=100;
        return tot/al.length;

    }
    public static Integer getIntAvg(Integer[] al){
        Integer tot = 0;
        for (int p = 0; p<al.length;p++){
            tot+=al[p];
        }
        return tot/al.length;
    }

    public static void main(String[] args) {
        int size = Integer.parseInt(args[0]);
        int experiments = Integer.parseInt(args[1]);
        long runningTotal = 0;
        long jtimestart;
        long jtimeend;
        long itimestart;
        long itimeend;
        long[] volTots = new long[experiments];
        long[] regTots = new long[experiments];
        long[] volTime = new long[experiments];
        long[] regTime = new long[experiments];
        for (int l=0; l<experiments;l++){
            jtimestart = System.nanoTime();
            for (int j = 0; j<size;j++){
                if(j%2==0) runningTotal+=j;
                if(j%2==1) runningTotal-=j;
            }
            jtimeend = System.nanoTime();
            regTots[l]=runningTotal;
            runningTotal=0;
            regTime[l]=jtimeend-jtimestart;
            itimestart = System.nanoTime();
            for (i=0;i<size;i++){
                if(i%2==0) runningTotal+=i;
                if(i%2==1) runningTotal-=i;
            }
            itimeend = System.nanoTime();
            volTime[l]=itimeend-itimestart;
            volTots[l]=runningTotal;
            itimeend=0;
            itimestart=0;
            jtimestart=0;
            jtimeend=0;
            runningTotal=0;
        }
        long regAvgTime = getAvg(regTime);
        long volAvgTime = getAvg(volTime);
        long regAvgTot = getAvg(regTots);
        long volAvgTot = getAvg(volTots);
        String regTimeRounded = ""+regAvgTime/100/1000000000.0;
        String volTimeRounded = ""+volAvgTime/100/1000000000.0;
        regTimeRounded=regTimeRounded.substring(0,7);
        volTimeRounded=volTimeRounded.substring(0,7);

        System.out.println("Task 1");
        System.out.println("Regular: "+regTimeRounded+" seconds");
        System.out.println("Volatile: "+volTimeRounded+" seconds");
        System.out.println("Avg regular sum: "+(regAvgTot/100)+".00");
        System.out.println("Avg volatile sum: "+(volAvgTot/100)+".00\n\nTask 2");

        //task 2

        int[] arr = new int[size];
        Random r = new Random(Long.parseLong(args[2]));
        long[] sumArr = new long[experiments];
        long arrSum=0;
        long firstTimeStart;
        long firstTimeEnd;
        long lastTimeStart;
        long lastTimeEnd;
        int lastRandElem;
        long[] firstTimes = new long[(size/10)*experiments];
        long[] lastTimes = new long[experiments];
        for(int s = 0; s<arr.length;s++){
            arr[s] = r.nextInt();
            //if(s%1000==0)System.out.println(arr[s]);
        }
        for(int s = 0; s<experiments;s++){
            //access from first 10%
            lastRandElem=size-r.nextInt(size/10);
            for (int firstLoop = 0; firstLoop<size/10;firstLoop++){
            firstTimeStart=System.nanoTime();
            arrSum+=arr[firstLoop];
            firstTimeEnd=System.nanoTime();
            //System.out.println(firstTimeEnd-firstTimeStart);
            firstTimes[((size/10)*s)+firstLoop]=firstTimeEnd-firstTimeStart;
            }
            //System.out.println(""+firstTimeEnd+"  and  "+firstTimeStart+r.nextInt(42));
            
            //access from last 10%
            if(experiments==1){
            arrSum-=arr[lastRandElem];
            arrSum+=arr[lastRandElem];
            }
            lastTimeStart=System.nanoTime();
            arrSum+=arr[lastRandElem];
            lastTimeEnd=System.nanoTime();
            lastTimes[s]=lastTimeEnd-lastTimeStart;
            sumArr[s]=arrSum;
            arrSum=0;
        }
        long arrSumAverage = getAvg(sumArr);
        long firstAvgTime = getAvg(firstTimes);
        long lastAvgTime = getAvg(lastTimes);
        System.out.println("Avg time to access known element: "+(firstAvgTime/100)+".00 nanoseconds");
        System.out.println("Avg time to access random element: "+(lastAvgTime/100)+".00 nanoseconds");
        System.out.println("Sum: "+arrSumAverage/(long)100+".00");
        //System.exit(0);

        //task 3


        TreeSet<Integer> ts = new TreeSet<>();
        ArrayList<Integer> al = new ArrayList<>(size);
        int findANum;
        long tsStartTime;
        long tsEndTime;
        long alStartTime;
        long alEndTime;
        long[] alTimes = new long[experiments];
        long[] tsTimes = new long[experiments];
        int addMe;
        
            for (int t = 0; t < size; t++){
                addMe = r.nextInt(size);
                al.add(addMe);
                ts.add(addMe);

            }

            for (int v = 0; v < experiments; v++){
            findANum = r.nextInt(size);
            tsStartTime = System.nanoTime();
            ts.contains(findANum);
            tsEndTime = System.nanoTime();
            alStartTime = System.nanoTime();
            al.contains(findANum);
            alEndTime = System.nanoTime();
            alTimes[v]= alEndTime-alStartTime;
            tsTimes[v]= tsEndTime-tsStartTime;
            ts.clear();
            al.clear();
        }
        System.out.println("\nTask 3");
        System.out.println("Avg time to find in set: "+(getAvg(tsTimes)/100)+".00 nanoseconds");
        System.out.println("Avg time to find in list: "+(getAvg(alTimes)/100)+".00 nanoseconds");
    }
}
